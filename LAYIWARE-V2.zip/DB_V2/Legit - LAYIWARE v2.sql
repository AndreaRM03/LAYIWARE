-- DROP DATABASE aseguradora;
-- Crear la base de datos
CREATE DATABASE aseguradora;

-- Seleccionar la base de datos recién creada
USE aseguradora;

-- Almacena información sobre números de teléfono
CREATE TABLE telefono (
  id_telefono INT PRIMARY KEY AUTO_INCREMENT,
  numero BIGINT NOT NULL,
  UNIQUE (numero)
);

-- Almacena información sobre direcciones
CREATE TABLE direccion (
  id_direccion INT PRIMARY KEY AUTO_INCREMENT,
  calle VARCHAR(255) NOT NULL,
  numero INT NOT NULL,
  codigo_postal VARCHAR(10) NOT NULL,
  colonia VARCHAR(255) NOT NULL,
  ciudad VARCHAR(255) NOT NULL,
  estado VARCHAR(255) NOT NULL,
  pais VARCHAR(255) NOT NULL
);

-- Almacena información sobre tipos de seguro
CREATE TABLE tipo_seguro (
  id_tipo_seguro INT PRIMARY KEY AUTO_INCREMENT,
  nombre_tipo VARCHAR(255) NOT NULL
);

-- Almacena información sobre sucursales
CREATE TABLE sucursal (
  id_sucursal INT PRIMARY KEY AUTO_INCREMENT,
  nombre_sucursal VARCHAR(255) NOT NULL,
  id_direccion INT,
  id_telefono INT,
  FOREIGN KEY (id_direccion) REFERENCES direccion(id_direccion),
  FOREIGN KEY (id_telefono) REFERENCES telefono(id_telefono)
);

-- Almacena información sobre empleados
CREATE TABLE empleado (
  id_empleado INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(255) NOT NULL,
  apellido_paterno VARCHAR(255) NOT NULL,
  apellido_materno VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  contrasena VARCHAR(255) NOT NULL,
  salario DECIMAL(10, 2),
  comision DECIMAL(5, 2),
  rol ENUM('admin', 'empleado') DEFAULT 'empleado',
  activo BOOLEAN DEFAULT TRUE
);

-- Almacena información sobre asegurados
CREATE TABLE asegurado (
  id_asegurado INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(255) NOT NULL,
  apellido_paterno VARCHAR(255) NOT NULL,
  apellido_materno VARCHAR(255) NOT NULL,
  rfc VARCHAR(13) NOT NULL,
  curp VARCHAR(18) NOT NULL,
  id_sucursal INT,
  FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal)
);

-- Almacena la relación muchos a muchos entre empleado y sucursal
CREATE TABLE empleado_sucursal (
  id_empleado INT,
  id_sucursal INT,
  PRIMARY KEY (id_empleado, id_sucursal),
  FOREIGN KEY (id_empleado) REFERENCES empleado(id_empleado),
  FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal)
);

-- Almacena información sobre seguros
CREATE TABLE seguro (
  id_seguro INT PRIMARY KEY AUTO_INCREMENT,
  id_asegurado INT,
  cantidad_asegurada DECIMAL(10, 2),
  folio VARCHAR(255) NOT NULL,
  vigencia DATE,
  fecha_recepcion DATE,
  FOREIGN KEY (id_asegurado) REFERENCES asegurado(id_asegurado)
);

-- Almacena la relación muchos a muchos entre seguro y tipo_seguro
CREATE TABLE seguro_tipo_seguro (
  id_seguro INT,
  id_tipo_seguro INT,
  PRIMARY KEY (id_seguro, id_tipo_seguro),
  FOREIGN KEY (id_seguro) REFERENCES seguro(id_seguro),
  FOREIGN KEY (id_tipo_seguro) REFERENCES tipo_seguro(id_tipo_seguro)
);

-- Almacena la relación muchos a muchos entre empleado y telefono
CREATE TABLE empleado_telefono (
  id_empleado INT,
  id_telefono INT,
  PRIMARY KEY (id_empleado, id_telefono),
  FOREIGN KEY (id_empleado) REFERENCES empleado(id_empleado),
  FOREIGN KEY (id_telefono) REFERENCES telefono(id_telefono)
);

-- Almacena la relación uno a uno entre asegurado, direccion y telefono
CREATE TABLE asegurado_direccion_telefono (
  id_asegurado INT PRIMARY KEY,
  id_direccion INT,
  id_telefono INT,
  FOREIGN KEY (id_asegurado) REFERENCES asegurado(id_asegurado),
  FOREIGN KEY (id_direccion) REFERENCES direccion(id_direccion),
  FOREIGN KEY (id_telefono) REFERENCES telefono(id_telefono)
);
