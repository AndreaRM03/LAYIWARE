-- DROP DATABASE aseguradora;
-- Crear la base de datos
CREATE DATABASE aseguradora;

-- Seleccionar la base de datos recién creada
USE aseguradora;

-- Crear las tablas sin dependencias

-- Almacena información sobre los números de teléfono
CREATE TABLE Telefono (
  idTelefono INT PRIMARY KEY AUTO_INCREMENT,
  numero BIGINT NOT NULL,
  UNIQUE (numero) -- Asegura que los números de teléfono sean únicos
);

-- Almacena información sobre direcciones
CREATE TABLE Direccion (
  idDireccion INT PRIMARY KEY AUTO_INCREMENT,
  calle VARCHAR(255) NOT NULL,
  numero INT NOT NULL,
  codigoPostal VARCHAR(10) NOT NULL,
  colonia VARCHAR(255) NOT NULL,
  ciudad VARCHAR(255) NOT NULL,
  estado VARCHAR(255) NOT NULL,
  pais VARCHAR(255) NOT NULL
);

-- Almacena información sobre empleados
CREATE TABLE Empleado (
  idEmpleado INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(255) NOT NULL,
  apellidoPaterno VARCHAR(255) NOT NULL,
  apellidoMaterno VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  contrasena VARCHAR(255) NOT NULL,
  salario DECIMAL(10, 2),
  comision DECIMAL(5, 2),
  rol ENUM('admin', 'empleado') DEFAULT 'empleado',
  activo BOOLEAN DEFAULT TRUE -- Indica si el empleado está activo o inactivo
);

-- Almacena información sobre sucursales
CREATE TABLE Sucursal (
  idSucursal INT PRIMARY KEY AUTO_INCREMENT,
  nombreSucursal VARCHAR(255) NOT NULL
);

-- Almacena información sobre asegurados
CREATE TABLE Asegurado (
  idAsegurado INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(255) NOT NULL,
  apellidoPaterno VARCHAR(255) NOT NULL,
  apellidoMaterno VARCHAR(255) NOT NULL,
  RFC VARCHAR(13) NOT NULL,
  CURP VARCHAR(18) NOT NULL,
  sucursalId INT, -- Agregado para establecer la relación
  FOREIGN KEY (sucursalId) REFERENCES Sucursal(idSucursal) -- Asegurado pertenece a una sucursal
);

-- Tablas de relaciones muchos a muchos (tablas intermedias)

-- Relaciona empleados con sucursales (muchos a muchos)
CREATE TABLE EmpleadoSucursal (
  idEmpleado INT,
  idSucursal INT,
  PRIMARY KEY (idEmpleado, idSucursal),
  FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado), -- Empleado puede pertenecer a varias sucursales
  FOREIGN KEY (idSucursal) REFERENCES Sucursal(idSucursal) -- Sucursal puede tener varios empleados
);

-- Relaciona asegurados con direcciones y teléfonos (uno a uno)
CREATE TABLE AseguradoDireccionTelefono (
  idAsegurado INT PRIMARY KEY,
  direccionId INT,
  telefonoId INT,
  FOREIGN KEY (idAsegurado) REFERENCES Asegurado(idAsegurado), -- Asegurado tiene una dirección y un teléfono
  FOREIGN KEY (direccionId) REFERENCES Direccion(idDireccion),
  FOREIGN KEY (telefonoId) REFERENCES Telefono(idTelefono)
);

-- Almacena información sobre seguros
CREATE TABLE Seguro (
  idSeguro INT PRIMARY KEY AUTO_INCREMENT,
  idAsegurado INT,
  tipo VARCHAR(255) NOT NULL,
  cantidadAsegurada DECIMAL(10, 2),
  folio VARCHAR(255) NOT NULL,
  vigencia DATE,
  fechaRecepcion DATE,
  FOREIGN KEY (idAsegurado) REFERENCES Asegurado(idAsegurado) -- Asegurado puede tener varios seguros
);

-- Almacena la relación entre Empleado y Teléfono (elimina dependencia transitiva)
CREATE TABLE EmpleadoTelefono (
  idEmpleado INT,
  telefonoId INT,
  PRIMARY KEY (idEmpleado, telefonoId),
  FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado),
  FOREIGN KEY (telefonoId) REFERENCES Telefono(idTelefono)
);